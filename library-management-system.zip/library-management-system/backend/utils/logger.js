const ActivityLog = require('../models/ActivityLog');
const Notification = require('../models/Notification');

// Logging must never break the main request, so errors are swallowed.
async function logActivity(user, action, details = {}) {
  try {
    await ActivityLog.create({
      userId: user?.id, userName: user?.name, role: user?.role, action, details,
    });
  } catch (e) { console.error('log error', e.message); }
}

async function notify(userId, type, message, amount) {
  try { await Notification.create({ userId, type, message, amount }); }
  catch (e) { console.error('notify error', e.message); }
}

module.exports = { logActivity, notify };
