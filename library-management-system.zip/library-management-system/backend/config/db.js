const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

let pool;
const getPool = () => pool;

async function initMySQL() {
  const base = {
    host: process.env.MYSQL_HOST || 'localhost',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
  };
  const dbName = process.env.MYSQL_DATABASE || 'library_db';

  const tmp = await mysql.createConnection(base);
  await tmp.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\``);
  await tmp.end();

  pool = mysql.createPool({
    ...base,
    database: dbName,
    waitForConnections: true,
    connectionLimit: 10,
    multipleStatements: true,
  });

  const schema = fs.readFileSync(path.join(__dirname, '../sql/schema.sql'), 'utf8');
  await pool.query(schema);

  // Default sections
  const defaults = ['Computer Science', 'Mathematics', 'Physics', 'Literature', 'History', 'Fiction'];
  for (const name of defaults) {
    await pool.query('INSERT IGNORE INTO sections (name) VALUES (?)', [name]);
  }

  // First librarian account
  const email = process.env.LIBRARIAN_EMAIL || 'librarian@library.com';
  const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (!rows.length) {
    const hash = await bcrypt.hash(process.env.LIBRARIAN_PASSWORD || 'admin123', 10);
    await pool.query(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)',
      [process.env.LIBRARIAN_NAME || 'Head Librarian', email, hash, 'librarian']
    );
    console.log(`Librarian account created: ${email}`);
  }
  console.log('MySQL connected');
}

async function initMongo() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/library_logs');
  console.log('MongoDB connected');
}

module.exports = { initMySQL, initMongo, getPool };
