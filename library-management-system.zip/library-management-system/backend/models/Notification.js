const mongoose = require('mongoose');

// NoSQL: per-student notifications and rewards/fines history
const NotificationSchema = new mongoose.Schema({
  userId: { type: Number, index: true },
  type: { type: String, enum: ['reward', 'fine', 'info'], default: 'info' },
  message: String,
  amount: Number, // points for reward, money for fine
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Notification', NotificationSchema);
