const mongoose = require('mongoose');

// NoSQL: flexible, append-only activity feed (details can differ per action)
const ActivityLogSchema = new mongoose.Schema({
  userId: Number,
  userName: String,
  role: String,
  action: String, // LOGIN, BORROW, RETURN, ADD_BOOK, REMOVE_STUDENT ...
  details: mongoose.Schema.Types.Mixed,
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('ActivityLog', ActivityLogSchema);
