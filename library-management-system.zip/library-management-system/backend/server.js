require('dotenv').config();
require('express-async-errors');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { initMySQL, initMongo } = require('./config/db');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/students', require('./routes/students'));
app.use('/api/books', require('./routes/books'));
app.use('/api/borrow', require('./routes/borrow'));
app.use('/api/dashboard', require('./routes/dashboard'));

// Serve the frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Catch-all error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

const PORT = process.env.PORT || 3000;

(async () => {
  try {
    await initMySQL();
    await initMongo();
    app.listen(PORT, () => console.log(`Library app running at http://localhost:${PORT}`));
  } catch (e) {
    console.error('Startup failed:', e.message);
    console.error('Check that MySQL and MongoDB are running and your .env is correct.');
    process.exit(1);
  }
})();
