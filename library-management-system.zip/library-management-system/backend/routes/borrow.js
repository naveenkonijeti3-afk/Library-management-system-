const router = require('express').Router();
const { getPool } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { logActivity, notify } = require('../utils/logger');

const LOAN_DAYS = () => Number(process.env.LOAN_DAYS || 14);
const FINE_PER_DAY = () => Number(process.env.FINE_PER_DAY || 5);
const REWARD = () => Number(process.env.REWARD_POINTS || 10);
const MAX_ACTIVE = () => Number(process.env.MAX_ACTIVE_BORROWS || 3);

router.use(authenticate);

const SELECT = `
  SELECT br.*, b.title, b.author, s.name AS section, u.name AS student_name, u.roll_no,
    (br.status = 'borrowed' AND br.due_date < NOW()) AS is_overdue,
    CASE WHEN br.status = 'borrowed' AND br.due_date < NOW()
      THEN CEIL(TIMESTAMPDIFF(SECOND, br.due_date, NOW()) / 86400) * ? ELSE br.fine_amount END AS current_fine
  FROM borrowals br
  JOIN books b ON b.id = br.book_id
  JOIN sections s ON s.id = b.section_id
  JOIN users u ON u.id = br.user_id`;

// Student: borrow a book
router.post('/', requireRole('student'), async (req, res) => {
  const pool = getPool();
  const conn = await pool.getConnection();
  try {
    const { bookId } = req.body;
    await conn.beginTransaction();

    const [[active]] = await conn.query(
      "SELECT COUNT(*) AS n FROM borrowals WHERE user_id = ? AND status = 'borrowed'", [req.user.id]);
    if (active.n >= MAX_ACTIVE()) {
      await conn.rollback();
      return res.status(400).json({ error: `You can borrow up to ${MAX_ACTIVE()} books at a time.` });
    }
    const [[unpaid]] = await conn.query(
      'SELECT COUNT(*) AS n FROM borrowals WHERE user_id = ? AND fine_amount > 0 AND fine_paid = 0', [req.user.id]);
    if (unpaid.n > 0) {
      await conn.rollback();
      return res.status(400).json({ error: 'Pay your pending fine before borrowing another book.' });
    }
    const [[dup]] = await conn.query(
      "SELECT COUNT(*) AS n FROM borrowals WHERE user_id = ? AND book_id = ? AND status = 'borrowed'", [req.user.id, bookId]);
    if (dup.n > 0) {
      await conn.rollback();
      return res.status(400).json({ error: 'You already have a copy of this book.' });
    }
    const [[book]] = await conn.query('SELECT * FROM books WHERE id = ? FOR UPDATE', [bookId]);
    if (!book) { await conn.rollback(); return res.status(404).json({ error: 'Book not found.' }); }
    if (book.available_copies < 1) { await conn.rollback(); return res.status(400).json({ error: 'No copies available right now.' }); }

    const now = new Date();
    const due = new Date(now.getTime() + LOAN_DAYS() * 86400000);
    await conn.query('UPDATE books SET available_copies = available_copies - 1 WHERE id = ?', [bookId]);
    const [r] = await conn.query(
      'INSERT INTO borrowals (user_id, book_id, borrowed_at, due_date) VALUES (?,?,?,?)', [req.user.id, bookId, now, due]);
    await conn.commit();

    await logActivity(req.user, 'BORROW', { borrowalId: r.insertId, title: book.title, due });
    await notify(req.user.id, 'info', `You borrowed "${book.title}". Return it by ${due.toDateString()} to earn ${REWARD()} points.`);
    res.status(201).json({ id: r.insertId, due_date: due });
  } catch (e) {
    await conn.rollback();
    console.error(e); res.status(500).json({ error: 'Server error.' });
  } finally { conn.release(); }
});

// Return a book (student returns own; librarian can process any)
router.post('/:id/return', async (req, res) => {
  const pool = getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[br]] = await conn.query(
      'SELECT br.*, b.title FROM borrowals br JOIN books b ON b.id = br.book_id WHERE br.id = ? FOR UPDATE', [req.params.id]);
    if (!br) { await conn.rollback(); return res.status(404).json({ error: 'Borrow record not found.' }); }
    if (req.user.role === 'student' && br.user_id !== req.user.id) {
      await conn.rollback(); return res.status(403).json({ error: 'This is not your book.' });
    }
    if (br.status === 'returned') { await conn.rollback(); return res.status(400).json({ error: 'Already returned.' }); }

    const now = new Date();
    const due = new Date(br.due_date);
    let fine = 0, points = 0, daysLate = 0;
    if (now <= due) {
      points = REWARD();
    } else {
      daysLate = Math.ceil((now - due) / 86400000);
      fine = daysLate * FINE_PER_DAY();
    }
    await conn.query(
      "UPDATE borrowals SET status='returned', returned_at=?, fine_amount=?, points_awarded=? WHERE id=?",
      [now, fine, points, br.id]);
    await conn.query('UPDATE books SET available_copies = available_copies + 1 WHERE id = ?', [br.book_id]);
    if (points) await conn.query('UPDATE users SET points = points + ? WHERE id = ?', [points, br.user_id]);
    await conn.commit();

    await logActivity(req.user, 'RETURN', { borrowalId: br.id, title: br.title, fine, points, daysLate });
    if (points) await notify(br.user_id, 'reward', `On-time return of "${br.title}". You earned ${points} points!`, points);
    if (fine) await notify(br.user_id, 'fine', `"${br.title}" was ${daysLate} day(s) late. Fine: ₹${fine}.`, fine);
    res.json({ onTime: !fine, points, fine, daysLate });
  } catch (e) {
    await conn.rollback();
    console.error(e); res.status(500).json({ error: 'Server error.' });
  } finally { conn.release(); }
});

// Pay fine (student pays own; librarian can mark as collected)
router.post('/:id/pay-fine', async (req, res) => {
  const pool = getPool();
  const [[br]] = await pool.query('SELECT * FROM borrowals WHERE id = ?', [req.params.id]);
  if (!br) return res.status(404).json({ error: 'Borrow record not found.' });
  if (req.user.role === 'student' && br.user_id !== req.user.id) return res.status(403).json({ error: 'Not your record.' });
  if (br.fine_amount <= 0 || br.fine_paid) return res.status(400).json({ error: 'There is no unpaid fine on this record.' });
  await pool.query('UPDATE borrowals SET fine_paid = 1 WHERE id = ?', [br.id]);
  await logActivity(req.user, 'PAY_FINE', { borrowalId: br.id, amount: br.fine_amount });
  await notify(br.user_id, 'info', `Fine of ₹${br.fine_amount} marked as paid.`);
  res.json({ ok: true });
});

// Student: my borrowals
router.get('/my', requireRole('student'), async (req, res) => {
  const [rows] = await getPool().query(`${SELECT} WHERE br.user_id = ? ORDER BY br.borrowed_at DESC`, [FINE_PER_DAY(), req.user.id]);
  res.json(rows);
});

// Librarian: all borrowals, ?status=borrowed|returned|overdue
router.get('/', requireRole('librarian'), async (req, res) => {
  let where = '';
  if (req.query.status === 'borrowed') where = "WHERE br.status = 'borrowed'";
  if (req.query.status === 'returned') where = "WHERE br.status = 'returned'";
  if (req.query.status === 'overdue') where = "WHERE br.status = 'borrowed' AND br.due_date < NOW()";
  const [rows] = await getPool().query(`${SELECT} ${where} ORDER BY br.borrowed_at DESC LIMIT 300`, [FINE_PER_DAY()]);
  res.json(rows);
});

module.exports = router;
