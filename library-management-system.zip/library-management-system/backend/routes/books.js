const router = require('express').Router();
const { getPool } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

router.use(authenticate);

// ---- Sections ----
router.get('/sections', async (req, res) => {
  const [rows] = await getPool().query(`
    SELECT s.id, s.name,
      COUNT(b.id) AS titles,
      COALESCE(SUM(b.total_copies),0) AS total_copies,
      COALESCE(SUM(b.available_copies),0) AS available_copies
    FROM sections s LEFT JOIN books b ON b.section_id = s.id
    GROUP BY s.id ORDER BY s.name`);
  res.json(rows);
});

router.post('/sections', requireRole('librarian'), async (req, res) => {
  const name = (req.body.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Enter a section name.' });
  try {
    const [r] = await getPool().query('INSERT INTO sections (name) VALUES (?)', [name]);
    await logActivity(req.user, 'ADD_SECTION', { name });
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That section already exists.' });
    res.status(500).json({ error: 'Server error.' });
  }
});

router.delete('/sections/:id', requireRole('librarian'), async (req, res) => {
  const [[c]] = await getPool().query('SELECT COUNT(*) AS n FROM books WHERE section_id = ?', [req.params.id]);
  if (c.n > 0) return res.status(400).json({ error: 'Move or remove the books in this section first.' });
  await getPool().query('DELETE FROM sections WHERE id = ?', [req.params.id]);
  res.json({ ok: true });
});

// ---- Books ----
// GET /api/books?q=search&section=ID
router.get('/', async (req, res) => {
  const { q, section } = req.query;
  const params = [];
  let where = 'WHERE 1=1';
  if (q) { where += ' AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  if (section) { where += ' AND b.section_id = ?'; params.push(section); }
  const [rows] = await getPool().query(
    `SELECT b.*, s.name AS section FROM books b JOIN sections s ON s.id = b.section_id ${where} ORDER BY b.title`, params);
  res.json(rows);
});

router.post('/', requireRole('librarian'), async (req, res) => {
  const { title, author, isbn, section_id, copies } = req.body;
  const n = parseInt(copies || 1, 10);
  if (!title || !author || !section_id) return res.status(400).json({ error: 'Title, author and section are required.' });
  if (!(n >= 1)) return res.status(400).json({ error: 'Copies must be at least 1.' });
  const [r] = await getPool().query(
    'INSERT INTO books (title, author, isbn, section_id, total_copies, available_copies) VALUES (?,?,?,?,?,?)',
    [title.trim(), author.trim(), isbn || null, section_id, n, n]);
  await logActivity(req.user, 'ADD_BOOK', { bookId: r.insertId, title, copies: n });
  res.status(201).json({ id: r.insertId });
});

// Change total copies (available copies adjust by the same difference)
router.put('/:id', requireRole('librarian'), async (req, res) => {
  const pool = getPool();
  const { title, author, isbn, section_id, copies } = req.body;
  const [[book]] = await pool.query('SELECT * FROM books WHERE id = ?', [req.params.id]);
  if (!book) return res.status(404).json({ error: 'Book not found.' });
  const total = copies ? parseInt(copies, 10) : book.total_copies;
  const out = book.total_copies - book.available_copies;
  if (total < out) return res.status(400).json({ error: `${out} copies are currently borrowed. Total cannot be lower.` });
  await pool.query(
    'UPDATE books SET title=?, author=?, isbn=?, section_id=?, total_copies=?, available_copies=? WHERE id=?',
    [title || book.title, author || book.author, isbn ?? book.isbn, section_id || book.section_id, total, total - out, book.id]);
  await logActivity(req.user, 'UPDATE_BOOK', { bookId: book.id });
  res.json({ ok: true });
});

router.delete('/:id', requireRole('librarian'), async (req, res) => {
  const pool = getPool();
  const [[c]] = await pool.query("SELECT COUNT(*) AS n FROM borrowals WHERE book_id = ? AND status='borrowed'", [req.params.id]);
  if (c.n > 0) return res.status(400).json({ error: 'Some copies are still borrowed. Wait for returns before removing.' });
  await pool.query('DELETE FROM books WHERE id = ?', [req.params.id]);
  await logActivity(req.user, 'REMOVE_BOOK', { bookId: req.params.id });
  res.json({ ok: true });
});

module.exports = router;
