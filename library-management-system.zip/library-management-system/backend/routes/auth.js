const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getPool } = require('../config/db');
const { logActivity } = require('../utils/logger');

// POST /api/auth/login  { email, password, role }
router.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });
    const [rows] = await getPool().query('SELECT * FROM users WHERE email = ?', [email.trim().toLowerCase()]);
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash)))
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    if (role && user.role !== role)
      return res.status(403).json({ error: `This account is a ${user.role} account. Choose the ${user.role} tab.` });

    const payload = { id: user.id, name: user.name, role: user.role };
    const token = jwt.sign(payload, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '8h' });
    await logActivity(payload, 'LOGIN');
    res.json({ token, user: { ...payload, email: user.email } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
