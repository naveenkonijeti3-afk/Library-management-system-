const router = require('express').Router();
const { getPool } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');
const ActivityLog = require('../models/ActivityLog');
const Notification = require('../models/Notification');

router.use(authenticate);

// Librarian: library-wide numbers
router.get('/stats', requireRole('librarian'), async (req, res) => {
  const pool = getPool();
  const [[t]] = await pool.query(`
    SELECT COUNT(*) AS titles, COALESCE(SUM(total_copies),0) AS total_copies,
           COALESCE(SUM(available_copies),0) AS available_copies FROM books`);
  const [[s]] = await pool.query("SELECT COUNT(*) AS students FROM users WHERE role='student'");
  const [[b]] = await pool.query(`
    SELECT SUM(status='borrowed') AS active,
           SUM(status='borrowed' AND due_date < NOW()) AS overdue,
           COALESCE(SUM(CASE WHEN fine_paid=1 THEN fine_amount END),0) AS fines_collected,
           COALESCE(SUM(CASE WHEN fine_paid=0 THEN fine_amount END),0) AS fines_pending
    FROM borrowals`);
  res.json({
    titles: t.titles, totalCopies: Number(t.total_copies), availableCopies: Number(t.available_copies),
    students: s.students, activeLoans: Number(b.active || 0), overdue: Number(b.overdue || 0),
    finesCollected: Number(b.fines_collected), finesPending: Number(b.fines_pending),
  });
});

// Librarian: recent activity from MongoDB
router.get('/logs', requireRole('librarian'), async (req, res) => {
  const logs = await ActivityLog.find().sort({ createdAt: -1 }).limit(40).lean();
  res.json(logs);
});

// Student: points + pending fines
router.get('/me', requireRole('student'), async (req, res) => {
  const pool = getPool();
  const [[u]] = await pool.query('SELECT points FROM users WHERE id = ?', [req.user.id]);
  const [[f]] = await pool.query(
    'SELECT COALESCE(SUM(fine_amount),0) AS pending FROM borrowals WHERE user_id = ? AND fine_paid = 0', [req.user.id]);
  const [[a]] = await pool.query(
    "SELECT COUNT(*) AS n FROM borrowals WHERE user_id = ? AND status='borrowed'", [req.user.id]);
  res.json({ points: u.points, pendingFines: Number(f.pending), activeLoans: a.n,
    maxLoans: Number(process.env.MAX_ACTIVE_BORROWS || 3) });
});

// Student: notifications / rewards & fines history from MongoDB
router.get('/notifications', requireRole('student'), async (req, res) => {
  const items = await Notification.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(30).lean();
  res.json(items);
});

module.exports = router;
