const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { getPool } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');

router.use(authenticate, requireRole('librarian'));

// List students with their current loan counts
router.get('/', async (req, res) => {
  const [rows] = await getPool().query(`
    SELECT u.id, u.name, u.email, u.roll_no, u.points, u.created_at,
      (SELECT COUNT(*) FROM borrowals b WHERE b.user_id = u.id AND b.status = 'borrowed') AS active_loans,
      (SELECT COALESCE(SUM(fine_amount),0) FROM borrowals b WHERE b.user_id = u.id AND b.fine_paid = 0) AS unpaid_fines
    FROM users u WHERE u.role = 'student' ORDER BY u.name`);
  res.json(rows);
});

// Add student
router.post('/', async (req, res) => {
  try {
    const { name, email, password, roll_no } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required.' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    const hash = await bcrypt.hash(password, 10);
    const [r] = await getPool().query(
      'INSERT INTO users (name, email, password_hash, role, roll_no) VALUES (?,?,?,?,?)',
      [name.trim(), email.trim().toLowerCase(), hash, 'student', roll_no || null]);
    await logActivity(req.user, 'ADD_STUDENT', { studentId: r.insertId, name });
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'A user with this email already exists.' });
    console.error(e); res.status(500).json({ error: 'Server error.' });
  }
});

// Remove student (blocked while books are still out)
router.delete('/:id', async (req, res) => {
  const pool = getPool();
  const [[s]] = await pool.query("SELECT id, name FROM users WHERE id = ? AND role = 'student'", [req.params.id]);
  if (!s) return res.status(404).json({ error: 'Student not found.' });
  const [[c]] = await pool.query("SELECT COUNT(*) AS n FROM borrowals WHERE user_id = ? AND status = 'borrowed'", [s.id]);
  if (c.n > 0) return res.status(400).json({ error: 'This student still has borrowed books. Collect them first.' });
  await pool.query('DELETE FROM users WHERE id = ?', [s.id]);
  await logActivity(req.user, 'REMOVE_STUDENT', { studentId: s.id, name: s.name });
  res.json({ ok: true });
});

module.exports = router;
