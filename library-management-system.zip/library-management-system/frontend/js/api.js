// Shared helpers used by every page

const api = {
  get token() { return localStorage.getItem('lib_token'); },
  get user() { return JSON.parse(localStorage.getItem('lib_user') || 'null'); },

  async request(method, url, body) {
    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(api.token ? { Authorization: `Bearer ${api.token}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && api.token) { api.logout(); return; }
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  },
  get: (u) => api.request('GET', u),
  post: (u, b) => api.request('POST', u, b || {}),
  put: (u, b) => api.request('PUT', u, b),
  del: (u) => api.request('DELETE', u),

  logout() {
    localStorage.removeItem('lib_token');
    localStorage.removeItem('lib_user');
    location.href = '/index.html';
  },

  // Redirect away if the wrong person opens a page
  guard(role) {
    const u = api.user;
    if (!api.token || !u || u.role !== role) { api.logout(); return null; }
    return u;
  },
};

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const fmtDate = (d) => d ? new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
const fmtDateTime = (d) => new Date(d).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const money = (n) => '₹' + Number(n || 0).toFixed(0);

function toast(msg, bad = false) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'show' + (bad ? ' bad' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.className = ''), 3200);
}

// Tab switching for nav.menu buttons with data-panel
function setupTabs(onShow) {
  const buttons = document.querySelectorAll('nav.menu button');
  buttons.forEach((btn) => btn.addEventListener('click', () => {
    buttons.forEach((b) => b.setAttribute('aria-selected', b === btn));
    document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === btn.dataset.panel));
    onShow && onShow(btn.dataset.panel);
  }));
}
