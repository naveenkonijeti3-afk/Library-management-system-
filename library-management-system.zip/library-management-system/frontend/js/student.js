const me = api.guard('student');
document.getElementById('who').textContent = me.name;
setupTabs((id) => { if (id === 'p-mine') loadMine(); if (id === 'p-rewards') loadNotes(); });

async function loadStats() {
  const s = await api.get('/api/dashboard/me');
  document.getElementById('stats').innerHTML = `
    <div class="stat points"><span>Reward points</span><strong>${s.points}</strong></div>
    <div class="stat ${s.pendingFines ? 'fine' : ''}"><span>Unpaid fines</span><strong>${money(s.pendingFines)}</strong></div>
    <div class="stat"><span>Books borrowed</span><strong>${s.activeLoans} / ${s.maxLoans}</strong></div>`;
}

async function loadSections() {
  const secs = await api.get('/api/books/sections');
  document.getElementById('sectionFilter').innerHTML =
    '<option value="">All sections</option>' + secs.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
}

async function loadBooks() {
  const q = encodeURIComponent(document.getElementById('q').value);
  const sec = document.getElementById('sectionFilter').value;
  const books = await api.get(`/api/books?q=${q}&section=${sec}`);
  document.getElementById('bookRows').innerHTML = books.length ? books.map((b) => `
    <tr>
      <td><strong>${esc(b.title)}</strong><div class="sub">${esc(b.author)}</div></td>
      <td>${esc(b.section)}</td>
      <td>${b.available_copies > 0
        ? `<span class="badge ok">${b.available_copies} of ${b.total_copies}</span>`
        : '<span class="badge late">All borrowed</span>'}</td>
      <td><button class="btn small" ${b.available_copies < 1 ? 'disabled' : ''} onclick="borrow(${b.id})">Borrow</button></td>
    </tr>`).join('') : '<tr><td colspan="4" class="empty">No books match your search.</td></tr>';
}

async function borrow(id) {
  try {
    const r = await api.post('/api/borrow', { bookId: id });
    toast(`Borrowed. Return by ${fmtDate(r.due_date)} to earn points.`);
    loadBooks(); loadStats();
  } catch (e) { toast(e.message, true); }
}

async function loadMine() {
  const rows = await api.get('/api/borrow/my');
  document.getElementById('myRows').innerHTML = rows.length ? rows.map((r) => {
    let status, action = '';
    if (r.status === 'borrowed') {
      status = r.is_overdue
        ? `<span class="badge late">Overdue · fine ${money(r.current_fine)}</span>`
        : '<span class="badge info">Borrowed</span>';
      action = `<button class="btn small" onclick="returnBook(${r.id})">Return</button>`;
    } else if (r.fine_amount > 0) {
      status = r.fine_paid ? `<span class="badge info">Late · fine ${money(r.fine_amount)} paid</span>`
                           : `<span class="badge late">Late · fine ${money(r.fine_amount)} due</span>`;
      if (!r.fine_paid) action = `<button class="btn small danger" onclick="payFine(${r.id})">Pay fine</button>`;
    } else {
      status = `<span class="badge gold">On time · +${r.points_awarded} points</span>`;
    }
    return `<tr>
      <td><strong>${esc(r.title)}</strong><div class="sub">${esc(r.author)}</div></td>
      <td>${fmtDate(r.borrowed_at)}</td><td>${fmtDate(r.due_date)}</td>
      <td>${status}</td><td><div class="actions">${action}</div></td></tr>`;
  }).join('') : '<tr><td colspan="5" class="empty">You have not borrowed any books yet. Open Find books to start.</td></tr>';
}

async function returnBook(id) {
  try {
    const r = await api.post(`/api/borrow/${id}/return`);
    r.onTime ? toast(`Returned on time. You earned ${r.points} points!`)
             : toast(`Returned ${r.daysLate} day(s) late. Fine: ${money(r.fine)}.`, true);
    loadMine(); loadStats();
  } catch (e) { toast(e.message, true); }
}

async function payFine(id) {
  try { await api.post(`/api/borrow/${id}/pay-fine`); toast('Fine paid.'); loadMine(); loadStats(); }
  catch (e) { toast(e.message, true); }
}

async function loadNotes() {
  const items = await api.get('/api/dashboard/notifications');
  document.getElementById('notes').innerHTML = items.length
    ? items.map((n) => `<li><span>${n.type === 'reward' ? '<span class="badge gold">Reward</span> '
        : n.type === 'fine' ? '<span class="badge late">Fine</span> ' : ''}${esc(n.message)}</span>
        <time>${fmtDateTime(n.createdAt)}</time></li>`).join('')
    : '<li><span class="empty" style="padding:0">Nothing yet. Return a book on time to earn your first reward.</span></li>';
}

document.getElementById('q').addEventListener('input', loadBooks);
document.getElementById('sectionFilter').addEventListener('change', loadBooks);
loadSections(); loadBooks(); loadStats();
