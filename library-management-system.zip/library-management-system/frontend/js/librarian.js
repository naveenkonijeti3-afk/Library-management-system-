const me = api.guard('librarian');
document.getElementById('who').textContent = me.name;
const $ = (id) => document.getElementById(id);
let sections = [];

setupTabs((id) => ({
  'p-overview': loadOverview, 'p-books': loadBooks, 'p-sections': loadSections,
  'p-loans': loadLoans, 'p-students': loadStudents,
}[id]()));

const run = async (fn) => { try { await fn(); } catch (e) { toast(e.message, true); } };

/* ---------- Overview ---------- */
async function loadOverview() {
  const s = await api.get('/api/dashboard/stats');
  $('stats').innerHTML = `
    <div class="stat"><span>Book titles</span><strong>${s.titles}</strong></div>
    <div class="stat"><span>Copies in library</span><strong>${s.availableCopies} / ${s.totalCopies}</strong></div>
    <div class="stat"><span>Students</span><strong>${s.students}</strong></div>
    <div class="stat"><span>Currently borrowed</span><strong>${s.activeLoans}</strong></div>
    <div class="stat ${s.overdue ? 'fine' : ''}"><span>Overdue</span><strong>${s.overdue}</strong></div>
    <div class="stat fine"><span>Fines pending</span><strong>${money(s.finesPending)}</strong></div>
    <div class="stat points"><span>Fines collected</span><strong>${money(s.finesCollected)}</strong></div>`;
  const logs = await api.get('/api/dashboard/logs');
  const describe = (l) => {
    const d = l.details || {};
    const map = {
      LOGIN: 'logged in', BORROW: `borrowed "${d.title}"`,
      RETURN: `returned "${d.title}"${d.fine ? ` (late, fine ${money(d.fine)})` : ` (on time, +${d.points} pts)`}`,
      ADD_BOOK: `added "${d.title}" (${d.copies} copies)`, REMOVE_BOOK: 'removed a book',
      ADD_STUDENT: `added student ${d.name}`, REMOVE_STUDENT: `removed student ${d.name}`,
      ADD_SECTION: `added section ${d.name}`, PAY_FINE: `fine of ${money(d.amount)} paid`, UPDATE_BOOK: 'updated a book',
    };
    return map[l.action] || l.action;
  };
  $('logs').innerHTML = logs.length
    ? logs.map((l) => `<li><span><strong>${esc(l.userName)}</strong> ${esc(describe(l))}</span><time>${fmtDateTime(l.createdAt)}</time></li>`).join('')
    : '<li><span class="empty" style="padding:0">No activity yet.</span></li>';
}

/* ---------- Sections ---------- */
async function loadSections() {
  sections = await api.get('/api/books/sections');
  $('secGrid').innerHTML = sections.map((s) => {
    const pct = s.total_copies ? Math.round((s.available_copies / s.total_copies) * 100) : 0;
    return `<div class="section-card">
      <h3>${esc(s.name)}</h3>
      <div class="sub">${s.titles} titles · ${s.total_copies} copies</div>
      <div class="bar"><i style="width:${pct}%"></i></div>
      <div class="sub">${s.available_copies} on the shelf, ${s.total_copies - s.available_copies} borrowed</div>
      <button class="btn ghost small" style="margin-top:10px" onclick="removeSection(${s.id})">Remove section</button>
    </div>`;
  }).join('');
  const opts = sections.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
  $('bSection').innerHTML = opts;
  $('sectionFilter').innerHTML = '<option value="">All sections</option>' + opts;
}
$('secForm').addEventListener('submit', (e) => { e.preventDefault(); run(async () => {
  await api.post('/api/books/sections', { name: $('secName').value });
  $('secName').value = ''; toast('Section added.'); loadSections();
}); });
const removeSection = (id) => confirm('Remove this section?') && run(async () => {
  await api.del(`/api/books/sections/${id}`); toast('Section removed.'); loadSections();
});

/* ---------- Books ---------- */
$('toggleBook').onclick = () => $('bookForm').classList.toggle('open');
async function loadBooks() {
  if (!sections.length) await loadSections();
  const q = encodeURIComponent($('q').value);
  const books = await api.get(`/api/books?q=${q}&section=${$('sectionFilter').value}`);
  $('bookRows').innerHTML = books.length ? books.map((b) => `
    <tr>
      <td><strong>${esc(b.title)}</strong><div class="sub">${esc(b.author)}${b.isbn ? ' · ISBN ' + esc(b.isbn) : ''}</div></td>
      <td>${esc(b.section)}</td>
      <td>${b.available_copies} of ${b.total_copies}</td>
      <td><div class="actions">
        <button class="btn ghost small" onclick="editCopies(${b.id}, ${b.total_copies})">Change copies</button>
        <button class="btn danger small" onclick="removeBook(${b.id})">Remove</button>
      </div></td>
    </tr>`).join('') : '<tr><td colspan="4" class="empty">No books found. Use Add book to stock the shelves.</td></tr>';
}
$('bookForm').addEventListener('submit', (e) => { e.preventDefault(); run(async () => {
  await api.post('/api/books', {
    title: $('bTitle').value, author: $('bAuthor').value, isbn: $('bIsbn').value,
    section_id: $('bSection').value, copies: $('bCopies').value,
  });
  e.target.reset(); toast('Book added.'); loadBooks();
}); });
const editCopies = (id, cur) => {
  const v = prompt('New total number of copies:', cur);
  if (v) run(async () => { await api.put(`/api/books/${id}`, { copies: v }); toast('Copies updated.'); loadBooks(); });
};
const removeBook = (id) => confirm('Remove this book from the library?') && run(async () => {
  await api.del(`/api/books/${id}`); toast('Book removed.'); loadBooks();
});
$('q').addEventListener('input', loadBooks);
$('sectionFilter').addEventListener('change', loadBooks);

/* ---------- Borrowals ---------- */
async function loadLoans() {
  const rows = await api.get(`/api/borrow?status=${$('loanFilter').value}`);
  $('loanRows').innerHTML = rows.length ? rows.map((r) => {
    let status = '', action = '';
    if (r.status === 'borrowed') {
      status = r.is_overdue ? `<span class="badge late">Overdue · ${money(r.current_fine)}</span>` : '<span class="badge info">Borrowed</span>';
      action = `<button class="btn small" onclick="accept(${r.id})">Accept return</button>`;
    } else if (r.fine_amount > 0) {
      status = `<span class="badge late">Late · fine ${money(r.fine_amount)} ${r.fine_paid ? 'paid' : 'due'}</span>`;
      if (!r.fine_paid) action = `<button class="btn small danger" onclick="collect(${r.id})">Mark fine paid</button>`;
    } else status = `<span class="badge ok">On time</span>`;
    return `<tr><td><strong>${esc(r.title)}</strong><div class="sub">${esc(r.section)}</div></td>
      <td>${esc(r.student_name)}<div class="sub">${esc(r.roll_no || '')}</div></td>
      <td>${fmtDate(r.borrowed_at)}</td><td>${fmtDate(r.due_date)}</td><td>${status}</td>
      <td><div class="actions">${action}</div></td></tr>`;
  }).join('') : '<tr><td colspan="6" class="empty">No records for this filter.</td></tr>';
}
$('loanFilter').addEventListener('change', loadLoans);
const accept = (id) => run(async () => {
  const r = await api.post(`/api/borrow/${id}/return`);
  r.onTime ? toast(`Accepted on time. Student earned ${r.points} points.`) : toast(`Accepted ${r.daysLate} day(s) late. Fine ${money(r.fine)}.`, true);
  loadLoans();
});
const collect = (id) => run(async () => { await api.post(`/api/borrow/${id}/pay-fine`); toast('Fine marked as paid.'); loadLoans(); });

/* ---------- Students ---------- */
$('toggleStudent').onclick = () => $('studentForm').classList.toggle('open');
async function loadStudents() {
  const rows = await api.get('/api/students');
  $('studentRows').innerHTML = rows.length ? rows.map((s) => `
    <tr><td><strong>${esc(s.name)}</strong><div class="sub">${esc(s.email)}</div></td>
      <td>${esc(s.roll_no || '—')}</td><td>${s.active_loans}</td><td>${s.points}</td>
      <td>${Number(s.unpaid_fines) ? `<span class="badge late">${money(s.unpaid_fines)}</span>` : '—'}</td>
      <td><button class="btn danger small" onclick="removeStudent(${s.id})">Remove</button></td></tr>`).join('')
    : '<tr><td colspan="6" class="empty">No students yet. Use Add student to create the first account.</td></tr>';
}
$('studentForm').addEventListener('submit', (e) => { e.preventDefault(); run(async () => {
  await api.post('/api/students', { name: $('sName').value, roll_no: $('sRoll').value, email: $('sEmail').value, password: $('sPass').value });
  e.target.reset(); toast('Student account created.'); loadStudents();
}); });
const removeStudent = (id) => confirm('Remove this student and their history?') && run(async () => {
  await api.del(`/api/students/${id}`); toast('Student removed.'); loadStudents();
});

loadSections().then(loadOverview);
