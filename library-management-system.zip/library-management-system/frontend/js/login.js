let role = 'student';

// Already logged in? Go straight to the right page.
if (api.token && api.user) {
  location.href = api.user.role === 'librarian' ? '/librarian.html' : '/student.html';
}

document.querySelectorAll('.tabs button').forEach((b) =>
  b.addEventListener('click', () => {
    role = b.dataset.role;
    document.querySelectorAll('.tabs button').forEach((x) => x.setAttribute('aria-selected', x === b));
  }));

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = document.getElementById('err');
  err.className = 'error';
  try {
    const data = await api.post('/api/auth/login', {
      email: document.getElementById('email').value,
      password: document.getElementById('password').value,
      role,
    });
    localStorage.setItem('lib_token', data.token);
    localStorage.setItem('lib_user', JSON.stringify(data.user));
    location.href = data.user.role === 'librarian' ? '/librarian.html' : '/student.html';
  } catch (ex) {
    err.textContent = ex.message;
    err.className = 'error show';
  }
});
